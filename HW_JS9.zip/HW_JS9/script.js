const inputText = document.getElementById('inp_text')
const buttonEnter = document.getElementById('enter')
const buttonDelete = document.getElementById('delete')
const taskList = document.getElementById('taskl')

let taskArray = [];

const addTask = () => {                                 
    let task = document.createElement('li')             

    let taskText = document.createElement('p')          
    taskText.innerHTML = `${inputText.value}`;

    let editImg = document.createElement('img')         
    editImg.setAttribute('src', 'images/Pencil.png')

    let deleteImg = document.createElement('img')       
    deleteImg.setAttribute('src', 'images/X.png')

    let checkbox = document.createElement('input')      
    checkbox.setAttribute('type', 'checkbox')

    taskList.appendChild(task)
    task.appendChild(checkbox)
    task.appendChild(taskText)
    task.appendChild(editImg)
    task.appendChild(deleteImg)
    inputText.value = ''
    taskArray.push(task)
    task.classL.add(`task${taskArray.length}`)
    taskText.classL.add(`text${taskArray.length}`)
    deleteImg.classL.add(`delete${taskArray.length}`)
    editImg.classL.add(`edit${taskArray.length}`)
    checkbox.classL.add(`checkbox${taskArray.length}`)
}

buttonEnter.addEventListener('click', addTask)              
inputText.addEventListener('keydown', (event) => {          
    if (event.key === 'Enter') addTask()
})

buttonDelete.addEventListener('click', () => {               
    taskList.innerHTML = ''
})

const deleteAndEditTask = (event) => {                         
    const item = event.target;
    for (let i=1; i <= taskArray.length; i++) {
        if (item.classL.value === `delete${i}`) {                    
            let elemDelete = document.getElementsByClassName(`task${i}`)
            elemDelete[0].parentNode.removeChild(elemDelete[0])
        }
        if (item.classL.value === `edit${i}`) {                      
            let parentEdit = item.parentElement
            let elemDelete = taskList.getElementsByClassName(`text${i}`) 
            elemDelete[0].parentNode.removeChild(elemDelete[0])          
            const newText = prompt('Type your Task')
            let task = document.createElement('p')                      
            task.classL.add(`text${i}`)
            task.innerHTML = `${newText}`
            parentEdit.insertBefore(task, item)                         
        }
        if (item.classL.value === `checkbox${i}`) {                  
            if (item.checked) {
                item.nexstEl.classL.remove('normal-text')
                item.nexstEl.classL.add('crossOut')
            } else {
                item.nexstEl.classL.remove('crossOut')
                item.nexstEl.classL.add('normal-text')
            }
        }
    }
}
taskList.addEventListener("click", deleteAndEditTask);         


